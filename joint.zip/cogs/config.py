import json
import traceback
import datetime
import sqlite3
from discord import TextChannel, ChannelType, Embed, Role, Member,  Message, User, SelectOption, Interaction, PartialEmoji, PermissionOverwrite
import discord
from discord.ext.commands import Cog, Context, group, hybrid_command, hybrid_group, command, AutoShardedBot as AB
from discord.ui import Select, View, Button
from typing import Union
from tools.checks import Perms as utils, Boosts
from tools.utils import EmbedBuilder, InvokeClass
from tools.utils import EmbedScript
from discord.ext import commands
from discord.utils import find

class config(Cog):
    def __init__(self, bot: AB):
        self.bot = bot
        self.db = sqlite3.connect("mediaonly.db")
        self.db.execute(
            'CREATE TABLE IF NOT EXISTS mediaonly (guild_id INTEGER, channel_id INTEGER)')
        self.conn = sqlite3.connect('fake_permissions.db')
        c = self.conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS fake_permissions 
                    (guild_id INTEGER, role_id INTEGER, permissions TEXT, PRIMARY KEY (guild_id, role_id))''')
        self.conn.commit()

        


    async def is_mediaonly(self, channel_id, guild_id):
        check = self.db.execute(
            "SELECT * FROM mediaonly WHERE guild_id = ? AND channel_id = ?", (guild_id, channel_id)).fetchone()
        return check is not None

    @commands.Cog.listener()
    async def on_message(self, message):
        if not message.guild:
            return
        if isinstance(message.author, User):
            return
        if message.author.guild_permissions.manage_guild:
            return
        if message.author.bot:
            return
        if message.attachments:
            return
        if await self.is_mediaonly(message.channel.id, message.guild.id):
            try:
                await message.delete()
            except:
                pass

    @group(invoke_without_command=True)
    async def mediaonly(self, ctx: Context):
        await ctx.create_pages()

    @mediaonly.command(name="add", description="delete messages that are not images", help="config", usage="[channel]", brief="manage_guild")
    @utils.get_perms("manage_guild")
    async def mediaonly_add(self, ctx: Context, *, channel: TextChannel):
        check = await self.db.fetchrow("SELECT * FROM mediaonly WHERE guild_id = $1 AND channel_id = $2", ctx.guild.id, channel.id)
        if check is not None:
            return await ctx.send(f"{channel.mention} is already added")
        elif check is None:
            await self.db.execute("INSERT INTO mediaonly VALUES ($1,$2)", ctx.guild.id, channel.id)
            return await ctx.send(f"added {channel.mention} as a mediaonly channel")

    @mediaonly.command(name="remove", description="unset media only", help="config", usage="[channel]", brief="manage_guild")
    @utils.get_perms("manage_guild")
    async def mediaonly_remove(self, ctx: Context, *, channel: TextChannel = None):
        if channel is not None:
            check = await self.db.fetchrow("SELECT * FROM mediaonly WHERE guild_id = $1 AND channel_id = $2", ctx.guild.id, channel.id)
            if check is None:
                return await ctx.send(f"{channel.mention} is not added")
            await self.db.execute("DELETE FROM mediaonly WHERE guild_id = $1 AND channel_id = $2", ctx.guild.id, channel.id)
            return await ctx.send(f"{channel.mention} isn't a **mediaonly** channel anymore")

        res = await self.db.fetch("SELECT * FROM mediaonly WHERE guild_id = $1", ctx.guild.id)
        if res is None:
            return await ctx.send("There is no **mediaonly** channel in this server")
        await self.db.execute("DELETE FROM mediaonly WHERE guild_id = $1", ctx.guild.id)
        return await ctx.send("Removed all channels")

    @mediaonly.command(name="list", description="return a list of mediaonly channels", help="config")
    async def mediaonly_list(self, ctx: Context):
        i = 0
        k = 1
        l = 0
        mes = ""
        number = []
        messages = []
        results = await self.db.execute("SELECT * FROM mediaonly WHERE guild_id = ?", (ctx.guild.id,))
        rows = results.fetchall()
        if len(rows) == 0:
            return await ctx.reply("there are no mediaonly channels")
        for result in rows:
            mes = f"{mes}`{k}` <#{result[1]}> ({result[1]})\n"
            k += 1
            l += 1
            if l == 10:
                messages.append(mes)
                number.append(Embed(
                    color=self.bot.color, title=f"mediaonly channels ({len(rows)})", description=messages[i]))
                i += 1
                mes = ""
                l = 0
        messages.append(mes)
        number.append(Embed(color=self.bot.color,
                      title=f"mediaonly channels ({len(rows)})", description=messages[i]))
        if len(number) > 1:
            return await ctx.paginator(number)
        return await ctx.send(embed=number[0])
    
    @group(invoke_without_command=True)
    async def prefix(self, ctx: Context):
        await ctx.create_pages()

    @hybrid_command(description="changes the guild prefix", usage="[prefix]", help="config", brief="manage guild")
    async def prefix(self, ctx: Context, prefix: str):
        if len(prefix) > 3:
            return await ctx.send("Uh oh! The prefix is too long")

        conn = sqlite3.connect('prefixes.db')
        c = conn.cursor()

        check = c.execute(
            "SELECT * FROM prefixes WHERE guild_id = ?", (ctx.guild.id,)).fetchone()
        if check is not None:
            c.execute("UPDATE prefixes SET prefix = ? WHERE guild_id = ?",
                      (prefix, ctx.guild.id))
        else:
            c.execute("INSERT INTO prefixes VALUES (?, ?)",
                      (ctx.guild.id, prefix))
        conn.commit()
        conn.close()

        return await ctx.send(f"guild prefix changed to `{prefix}`".capitalize())
    
    @group(invoke_without_command=True)
    async def selfprefix(self, ctx: Context):
        await ctx.create_pages()

    @hybrid_command(description="set your own prefix", usage="[prefix]", help="config")
    async def selfprefix(self, ctx: Context, prefix: str):
        if len(prefix) > 3 and prefix.lower() != "none":
            return await ctx.send("Uh oh! The prefix is too long")

        conn = sqlite3.connect('prefixes.db')
        c = conn.cursor()

        if prefix.lower() == "none":
            check = c.execute(
                "SELECT * FROM selfprefix WHERE user_id = ?", (ctx.author.id,)).fetchone()
            if check is not None:
                c.execute("DELETE FROM selfprefix WHERE user_id = ?",
                          (ctx.author.id,))
                conn.commit()
                conn.close()
                return await ctx.send("Removed your self prefix")
            elif check is None:
                conn.close()
                return await ctx.send("you don't have a self prefix".capitalize())
        else:
            result = c.execute(
                "SELECT * FROM selfprefix WHERE user_id = ?", (ctx.author.id,)).fetchone()
            if result is not None:
                c.execute(
                    "UPDATE selfprefix SET prefix = ? WHERE user_id = ?", (prefix, ctx.author.id))
            elif result is None:
                c.execute("INSERT INTO selfprefix VALUES (?, ?)",
                          (ctx.author.id, prefix))
            conn.commit()
            conn.close()
            return await ctx.send(f"self prefix changed to `{prefix}`".capitalize())
        
    @commands.group(invoke_without_command=True, aliases=["fakeperms"])
    async def fakepermissions(self, ctx):
        await ctx.create_pages()

    @fakepermissions.command(description="edit fake permissions for a role", help="config", usage="[role]", brief="server owner")
    @utils.server_owner()
    async def edit(self, ctx: Context, *, role: Union[Role, str]=None):
        if isinstance(role, str):
            role = find(lambda r: r.name.lower() == role.lower(), ctx.guild.roles)
            if role is None:
                return await ctx.send("This is not a valid role")

        perms = ["administrator", "manage_guild", "manage_roles", "manage_channels", "manage_messages", "manage_nicknames", "manage_emojis", "ban_members", "kick_members", "moderate_members"]
        options = [SelectOption(label=perm.replace("_", " "), value=perm) for perm in perms]
        embed = Embed(color=self.bot.color, description="🔍 Which permissions would you like to add to {}?".format(role.mention))
        select = Select(placeholder="select permissions", max_values=10, options=options)

        async def select_callback(interaction: Interaction):
            if ctx.author != interaction.user:
                return await self.bot.ext.send(interaction, "This is not your embed", ephemeral=True)
            data = json.dumps(select.values)
            check = self.conn.execute("SELECT permissions FROM fake_permissions WHERE guild_id = ? AND role_id = ?", (interaction.guild.id, role.id)).fetchone()
            if not check:
                self.conn.execute("INSERT INTO fake_permissions VALUES (?,?,?)", (interaction.guild.id, role.id, data))
            else:
                self.conn.execute("UPDATE fake_permissions SET permissions = ? WHERE guild_id = ? AND role_id = ?", (data, interaction.guild.id, role.id))
            self.conn.commit()
            await interaction.response.edit_message(embed=Embed(color=self.bot.color, description=f"{self.bot.yes} {interaction.user.mention}: Added **{len(select.values)}** permission{'s' if len(select.values) > 1 else ''} to {role.mention}"), view=None)

        select.callback = select_callback
        view = View()
        view.add_item(select)
        await ctx.reply(embed=embed, view=view)

    @fakepermissions.command(name="list", description="list the permissions of a specific role", help="config", usage="[role]")
    async def fakeperms_list(self, ctx: Context, *, role: Union[Role, str]): 
        if isinstance(role, str): 
            role = ctx.find_role(role)
            if role is None: return await ctx.send("This is not a valid role") 
        
        async with self.conn.execute("SELECT permissions FROM fake_permissions WHERE guild_id = ? AND role_id = ?", (ctx.guild.id, role.id)) as cursor:
            check = await cursor.fetchone()
        if check is None: return await ctx.send("This role has no fake permissions")
        permissions = json.loads(check['permissions'])
        embed = Embed(color=self.bot.color, title=f"@{role.name}'s fake permissions", description="\n".join([f"`{permissions.index(perm)+1}` {perm}" for perm in permissions]))
        embed.set_thumbnail(url=role.display_icon)
        return await ctx.reply(embed=embed)
    





async def setup(bot):
    await bot.add_cog(config(bot))
